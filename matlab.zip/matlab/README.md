## Code and Tests for Continuous Time Methods
The documentation of these algorithms is in:
* General discretization of (time-independent) operators with finite differences: [operator_discretization_finite_differences.pdf](../operator_discretization_finite_differences.pdf)
* Solving optimal stopping problems: [optimal_stopping.pdf](../optimal_stopping.pdf)
