
## Examples
* For variational methods to solve problems with option values, see [optimal_stopping/](optimal_stopping) 